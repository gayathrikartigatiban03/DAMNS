<?php
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', realpath(dirname(__FILE__))); // Defines the root path of the project
}

if (!defined('BASE_URL')) {
    define('BASE_URL', '/DAMNS'); // Defines the base URL for the project
}