<?php
include('../db_con.php');
include('./student_nav.php');

$RegNo = $_SESSION['uid'];


// Query student table to get Sem, Department, and Name
$result_student = mysqli_query($con, "SELECT Sem, Department FROM student WHERE RegNo = '$RegNo'");
if (!$result_student) {
    echo "Error: " . mysqli_error($con);
    exit();
}

// Fetch Sem, Department, and Name
$row_student = mysqli_fetch_assoc($result_student);
$sem = $row_student['Sem'];
$department = $row_student['Department'];


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            background-image: url('../images/back2.jpg'); 
            /* filter: blur(8px);Replace 'path_to_your_background_image.jpg' with your image path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        h1, h2 {
            text-align: center;
            color:  #002a5d;
            margin: 20px;
        }

        .row {
            display: flex;
            flex-direction: row;
            align-items: flex-start;
            justify-content: center;
            flex-grow: 1;
            margin: 20px;
        }

        .timetable, .notifications {
            margin: 10px;
            padding: 40px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            background-color: #ffffff;
        }

        .timetable {
            width: 80%;
        }

        .timetable table {
            width: 100%;
            border-collapse: collapse;
        }

        .timetable th,
        .timetable td {
            border: 1px solid   #002a5d;
            padding: 10px;
            text-align: center;
        }

        .timetable th {
            background-color:  #002a5d;
            color: #ffffff;
        }

        .timetable tbody tr:nth-child(odd) {
            background-color:  #ffffff;
        }

        .timetable tbody tr:nth-child(even) {
            background-image: url('../images/back2.jpg'); 
            background-size: cover;
            background-position: center;

            background-repeat: no-repeat;
        }

        .vertical-text {
            writing-mode: vertical-rl;
            transform: rotate(180deg);
            white-space: nowrap;
            padding: 10px;
            margin:0px;
            background-image: url('../images/back2.jpg'); /* Replace 'path_to_your_background_image.jpg' with your image path */
            background-size: cover;
            color:  #002a5d;
        }

        .notifications {
            width: 35%;
            padding: 10px;
            background-color: white;
            color:  #FFD700;
            overflow-y: auto;
            text-align: center;
        }

        .notification-card {
            background-color: #002a5d;
            color: white;
            border: 1px solid #66bb6a;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .notification-card h3 {
            margin-top: 0;
        }

        .go-now-btn {
            background-color:  #FFD700;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin-top: 10px;
        }
        footer {
        margin-top: 20px;
        color: white;
        text-align: center;
        /* padding: 10px 0; */
        position: fixed;
        width: 100%;
        bottom: 0;
    }

        @media only screen and (max-width: 1024px) {
            .row {
                flex-direction: column;
                align-items: center;
            }

            .timetable,
            .notifications {
                width: 90%;
                margin: 10px 0;
            }

            .timetable table {
                overflow-y: auto;
                overflow-x: auto;
            }

            .timetable th,
            .timetable td {
                padding: 8px;
            }
        }
    </style>
</head>

<body>
    <div class="row">
        <div class="notifications">
            <h2>Notifications</h2>
            <?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Assuming $con is your database connection object and $sem_student, $department are your parameters

// Step 1: Retrieve notifications based on Sem
$query = "SELECT datetime, description, link, Department FROM notification WHERE Sem=?";
if ($stmt = $con->prepare($query)) {
    $stmt->bind_param('i', $sem);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Array to store notifications
        $notifications = [];

        // Fetch all notifications matching Sem
        while ($row = $result->fetch_assoc()) {
            $notifications[] = $row;
        }

        // Step 2: Filter notifications based on Department (NULL or specific)
        echo '<div class="notifications-container">';
        foreach ($notifications as $notification) {
            // Check if Department is NULL or matches $department
            if ($notification['Department'] === null || $notification['Department'] === $department) {
                echo '<div class="notification-card">';
                echo '<h3>' . htmlspecialchars($notification['datetime']) . '</h3>';
                echo '<p>' . htmlspecialchars($notification['description']) . '</p>';
                if (!empty($notification['link'])) {
                    echo '<a href="' . htmlspecialchars($notification['link']) . '" class="go-now-btn">Go Now</a>';
                }
                echo '</div>';
            }
        }
        echo '</div>';
    } else {
        echo '<p>No notifications found.</p>';
    }

    $stmt->close();
} else {
    echo '<p>Error fetching notifications: ' . $con->error . '</p>';
}

$con->close(); // Close the database connection
?>

            
        </div>
        <div class="timetable">
            <h1>TIME TABLE</h1>
            <table>
                <thead>
                    <tr>
                        <th>Day</th>
                        <th>9:20 - 10:10</th>
                        <th>10:10 - 11:00</th>
                        <th>11:00 - 11:10</th>
                        <th>11:10 - 12:00</th>
                        <th>12:00 - 12:50</th>
                        <th>12:50 - 1:40</th>
                        <th>1:40 - 2:30</th>
                        <th>2:30 - 3:20</th>
                        <th>3:20 - 4:10</th>
                        <th>4:10 - 5:00</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Monday</td>
                        <td>Math</td>
                        <td>English</td>
                        <td class="vertical-text" rowspan="6">Break</td>
                        <td>Science</td>
                        <td>History</td>
                        <td class="vertical-text" rowspan="6">Lunch Break</td>
                        <td>Geography</td>
                        <td>Computer</td>
                        <td>Art</td>
                        <td>History</td>
                    </tr>
                    <tr>
                        <td>Tuesday</td>
                        <td>English</td>
                        <td>Math</td>
                        <td>Geography</td>
                        <td>Science</td>
                        <td>History</td>
                        <td>Art</td>
                        <td>Computer</td>
                        <td>Science</td>
                    </tr>
                    <tr>
                        <td>Wednesday</td>
                        <td>History</td>
                        <td>Science</td>
                        <td>Math</td>
                        <td>English</td>
                        <td>Art</td>
                        <td>Geography</td>
                        <td>English</td>
                        <td>Math</td>
                    </tr>
                    <tr>
                        <td>Thursday</td>
                        <td>Science</td>
                        <td>History</td>
                        <td>English</td>
                        <td>Math</td>
                        <td>Computer</td>
                        <td>Math</td>
                        <td>Geography</td>
                        <td>English</td>
                    </tr>
                    <tr>
                        <td>Friday</td>
                        <td>Math</td>
                        <td>Geography</td>
                        <td>History</td>
                        <td>Art</td>
                        <td>English</td>
                        <td>Science</td>
                        <td>Math</td>
                        <td>Computer</td>
                    </tr>
                    <tr>
                        <td>Saturday</td>
                        <td>Sports</td>
                        <td>Art</td>
                        <td>Computer</td>
                        <td>Math</td>
                        <td>Geography</td>
                        <td>English</td>
                        <td>History</td>
                        <td>Science</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</body>

<footer>
    <?php include('./student_footer.php'); ?>
</footer>

</html>
