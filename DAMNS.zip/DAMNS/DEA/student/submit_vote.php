<?php
session_start();
include('../../db_con.php'); // Adjust the path as per your file structure

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['uid'])) {
    die("No registration number found in session.");
}
$RegNo = $_SESSION['uid'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['elective_choices']) || !is_array($_POST['elective_choices'])) {
        die("No electives selected.");
    }

    $elective_choices = $_POST['elective_choices'];
    $max_choices = intval($_POST['max_choices']);

    if (count($elective_choices) > $max_choices) {
        die("You have selected more than the allowed number of electives.");
    }

    // Begin a transaction
    $con->begin_transaction();

    try {
        // Check if the student has already voted
        $query = "SELECT COUNT(*) as vote_count FROM votes_pe WHERE RegNo = ?";
        $stmt = $con->prepare($query);
        $stmt->bind_param("s", $RegNo);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        if ($row['vote_count'] > 0) {
            throw new Exception("You have already voted.");
        }

        // Correct the SQL query to include all required columns
        $query = "INSERT INTO votes_pe (RegNo, Subject_code, Name, Sem, Department) VALUES (?, ?, ?, ?, ?)";
        $stmt = $con->prepare($query);

        if (!$stmt) {
            throw new Exception("Prepare failed: " . $con->error);
        }

        foreach ($elective_choices as $peid) {
            // Fetch the subject details for the given Peid
            $subject_query = "SELECT Subject_code, Name, Sem, Department FROM pe WHERE Peid = ?";
            $subject_stmt = $con->prepare($subject_query);
            $subject_stmt->bind_param("s", $peid);
            $subject_stmt->execute();
            $subject_result = $subject_stmt->get_result();
            $subject_row = $subject_result->fetch_assoc();

            if (!$subject_row) {
                throw new Exception("No subject found with the given Peid: " . htmlspecialchars($peid));
            }

            $subject_code = $subject_row['Subject_code'];
            $subject_name = $subject_row['Name'];
            $Sem = $subject_row['Sem'];
            $Department = $subject_row['Department'];

            // Debugging: Print values before insertion
            echo "Inserting: RegNo={$RegNo}, Subject_code={$subject_code}, Name={$subject_name}, Sem={$Sem}, Department={$Department}<br>";

            // Bind parameters to the statement
            $stmt->bind_param("sssis", $RegNo, $subject_code, $subject_name, $Sem, $Department);

            if (!$stmt->execute()) {
                throw new Exception("Execute failed: " . $stmt->error);
            }

            // Increment the vote count for the selected course
            $vote_query = "UPDATE pe SET vote = vote + 1 WHERE Peid = ?";
            $vote_stmt = $con->prepare($vote_query);
            if (!$vote_stmt) {
                throw new Exception("Prepare failed for vote update: " . $con->error);
            }
            $vote_stmt->bind_param("s", $peid);
            if (!$vote_stmt->execute()) {
                throw new Exception("Execute failed for vote update: " . $vote_stmt->error);
            }
        }

        // Commit the transaction
        $con->commit();
        echo "Your votes have been successfully recorded.";
    } catch (Exception $e) {
        // Rollback the transaction if something goes wrong
        $con->rollback();
        die("Failed to record votes: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Vote Submission</title>
</head>
<body>
    <h1>Thank you for voting!</h1>
    <p>Your votes have been successfully recorded.</p>
</body>
</html>
