<?php
include('../../student/student_nav.php');
include('../../db_con.php'); // Adjust the path as per your file structure


$RegNo = $_SESSION['uid'];

// Fetch the student's semester
$query_sem = "SELECT Sem FROM student WHERE RegNo = ?";
if ($stmt1 = $con->prepare($query_sem)) {
    $stmt1->bind_param("i", $RegNo);
    $stmt1->execute();
    $result1 = $stmt1->get_result();

    if ($result1->num_rows > 0) {
        $sem_row = $result1->fetch_assoc();
        $sem_student = $sem_row['Sem'];
    } else {
        echo '<p>No semester information found for the student.</p>';
    }

    $stmt1->close();
} else {
    echo '<p>Error fetching semester information.</p>';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            background-image: url('../../images/back2.jpg'); /* Replace 'path_to_your_background_image.jpg' with your image path */
            background-size: cover;
            background-position: center;
           
            /* background-repeat: no-repeat; */
        }

        h1, h2 {
            text-align: center;
            color: #002a5d;
            margin: 20px;
            font-family: 'Montserrat', sans-serif;
        }

        .container {
            display: flex;
            justify-content: center;
            padding: 20px;
        }

        .notifications {
            width: 80%;
            padding: 20px;
            background-color: white;
            color: #35424a;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .notification-card {
            background-color: #002a5d;
            color: white;
            border: 1px solid #66bb6a;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .notification-card h3 {
            margin-top: 0;
            font-family: 'Montserrat', sans-serif;
        }

        .notification-card p {
            font-size: 1.1em;
            line-height: 1.6;
            font-family: 'Roboto', sans-serif;
        }

        .highlight {
            background-color: #FFD700;
            padding: 0 5px;
            border-radius: 3px;
            color: #002a5d;
        }

        .go-now-btn {
            background-color: #FFD700;
            color: #002a5d;
            border: none;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin-top: 10px;
        }

        footer {
            margin-top: 20px;
            color: white;
            text-align: center;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="notifications">
            <h2>Notifications</h2>
            <?php
            // Query to fetch notifications
            $query = "SELECT datetime, description, link FROM notification WHERE Sem=?";
            if ($stmt = $con->prepare($query)) {
                $stmt->bind_param('i', $sem_student);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    // Output data for each row
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="notification-card">';
                        echo '<h3>' . htmlspecialchars($row['datetime']) . '</h3>';
                        echo '<p>' . str_replace(['Open elective', 'Professional elective'], ['<span class="highlight">Open elective</span>', '<span class="highlight">Professional elective</span>'], htmlspecialchars($row['description'])) . '</p>';
                        if (!empty($row['link'])) {
                            echo '<a href="' . htmlspecialchars($row['link']) . '" class="go-now-btn">Go Now</a>';
                        }
                        echo '</div>';
                    }
                } else {
                    echo '<p>No notifications.</p>';
                }

                $stmt->close();
            } else {
                echo '<p>Error fetching notifications.</p>';
            }
            ?>
        </div>
    </div>

  
    <footer>
        <?php include('../../student/student_footer.php'); ?>
    </footer>
</body>

</html>
