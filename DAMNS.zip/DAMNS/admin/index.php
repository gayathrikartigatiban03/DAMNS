<?php
include('../config.php');
include('./sidebar.php');

include('footer.php');
