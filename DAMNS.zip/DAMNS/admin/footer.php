<style>
footer {
    position: fixed;
    bottom: 0;
    text-align: center;
    padding: 10px;
    background: white;
    color: #0e2238;
    width: 100%;
    margin-top: 10px;
}
</style>
<div class="footer">
    <p>&copy;
        2024 DANS Admin Panel.</p>
</div>