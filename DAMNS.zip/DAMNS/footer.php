<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
.footer {
    background-color: #242333;
 
    bottom: 0;
    text-align: center;
    padding: 20px;
    color: white;
    width: 100%;
    margin-top: 10px;
}
</style>

<body>
    <div class="footer">
        <p>&copy;
            PUDUCHERRY TECHNOLOGICAL UNIVERSITY</p>
    </div>
</body>

</html>