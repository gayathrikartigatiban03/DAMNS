<?php
include('../db_con.php');
include('./staff_nav.php');

$staff_id = $_SESSION['uid'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <style>
        /* Base Styles */
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        h1, h2 {
            text-align: center;
            color: #333333;
            margin: 20px;
        }

        .row {
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: center;
            flex-grow: 1;
            margin: 20px;
        }

        .timetable, .courses {
            margin: 10px;
            padding: 40px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            background-color: #ffffff;
        }

        .timetable {
            width: 65%;
            transition: transform 0.3s ease;
        }

        .timetable:hover {
            transform: scale(1.02);
            overflow-x:auto;
        }

        .timetable table {
            width: 100%;
            border-collapse: collapse;
        }

        .timetable th,
        .timetable td {
            border: 1px solid #01B0D3;
            padding: 10px;
            text-align: center;
        }

        .timetable th {
            background-color: #01B0D3;
            color: #ffffff;
        }

        .timetable tbody tr:nth-child(odd) {
            background-color: #f9f9f9;
        }

        .timetable tbody tr:nth-child(even) {
            background-color: #ececec;
        }

        .vertical-text {
            writing-mode: vertical-rl;
            transform: rotate(180deg);
            white-space: nowrap;
            padding: 10px;
            background-color: #f4f4f9;
            color: #01B0D3;
        }

        .courses {
            width: 30%;
            background-color: #01B0D3;
            color: #ffffff;
            text-align: center;
            overflow-y: auto;
        }

        .course-link {
            color: #ffffff;
            text-decoration: none;
        }

        .course-card {
            background-color: #ffffff;
            color: #333333;
            border: 1px solid #01B0D3;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        @media only screen and (max-width: 1024px) {
            .row {
                flex-direction: column;
                align-items: center;
            }
            
            .timetable,
            .courses {
                width: 90%;
                margin: 10px 0;
            }

            .timetable table {
                overflow-y: auto;
                overflow-x: auto;

            }

            .timetable th,
            .timetable td {
                padding: 8px;
            }
        }
    </style>
</head>

<body>
    <div class="row">
        <div class="timetable">
            <h1>TIME TABLE</h1>
            <table>
                <thead>
                    <tr>
                        <th>Day</th>
                        <th>9:20 - 10:10</th>
                        <th>10:10 - 11:00</th>
                        <th>11:00 - 11:10</th>
                        <th>11:10 - 12:00</th>
                        <th>12:00 - 12:50</th>
                        <th>12:50 - 1:40</th>
                        <th>1:40 - 2:30</th>
                        <th>2:30 - 3:20</th>
                        <th>3:20 - 4:10</th>
                        <th>4:10 - 5:00</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Monday</td>
                        <td>Math</td>
                        <td>English</td>
                        <td class="vertical-text" rowspan="6">Break</td>
                        <td>Science</td>
                        <td>History</td>
                        <td class="vertical-text" rowspan="6">Lunch Break</td>
                        <td>Geography</td>
                        <td>Computer</td>
                        <td>Art</td>
                        <td>History</td>
                    </tr>
                    <tr>
                        <td>Tuesday</td>
                        <td>English</td>
                        <td>Math</td>
                        <td>Geography</td>
                        <td>Science</td>
                        <td>History</td>
                        <td>Art</td>
                        <td>Computer</td>
                        <td>Science</td>
                    </tr>
                    <tr>
                        <td>Wednesday</td>
                        <td>History</td>
                        <td>Science</td>
                        <td>Math</td>
                        <td>English</td>
                        <td>Art</td>
                        <td>Geography</td>
                        <td>English</td>
                        <td>Math</td>
                    </tr>
                    <tr>
                        <td>Thursday</td>
                        <td>Science</td>
                        <td>History</td>
                        <td>English</td>
                        <td>Math</td>
                        <td>Computer</td>
                        <td>Math</td>
                        <td>Geography</td>
                        <td>English</td>
                    </tr>
                    <tr>
                        <td>Friday</td>
                        <td>Math</td>
                        <td>Geography</td>
                        <td>History</td>
                        <td>Art</td>
                        <td>English</td>
                        <td>Science</td>
                        <td>Math</td>
                        <td>Computer</td>
                    </tr>
                    <tr>
                        <td>Saturday</td>
                        <td>Sports</td>
                        <td>Art</td>
                        <td>Computer</td>
                        <td>Math</td>
                        <td>Geography</td>
                        <td>English</td>
                        <td>History</td>
                        <td>Science</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="courses">
            <h2>Courses</h2>
            <?php
            // Query to fetch courses assigned to the staff member
            $query = "SELECT Subject_code, Name, Sem, Department FROM course WHERE Staff_id = ?";
            if ($stmt = $con->prepare($query)) {
                $stmt->bind_param("s", $staff_id);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    // Output data for each row
                    while ($row = $result->fetch_assoc()) {
                        echo '<a href="../DAM/staff/hour_choose.php?subject_code=' . urlencode($row['Subject_code']) . '" class="course-link">';
                        echo '<div class="course-card">';
                        echo '<h3>' . htmlspecialchars($row['Name']) . '</h3>';
                        echo '<p>Subject Code: ' . htmlspecialchars($row['Subject_code']) . '</p>';
                        echo '<p>Department: ' . htmlspecialchars($row['Department']) . '</p>';
                        echo '</div>';
                        echo '</a>';
                    }
                } else {
                    echo '<p>No courses assigned.</p>';
                }

                $stmt->close();
            } else {
                echo '<p>Error fetching courses.</p>';
            }
            ?>
        </div>
    </div>
</body>

<footer>
    <?php include('../footer.php'); ?>
</footer>

</html>
